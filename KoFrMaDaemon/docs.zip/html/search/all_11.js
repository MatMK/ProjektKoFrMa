var searchData=
[
  ['registerdata',['RegisterData',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_register_data.html',1,'KoFrMaDaemon::ConnectionToServer']]],
  ['relativepath',['RelativePath',['../class_ko_fr_ma_daemon_1_1_backup_1_1_file_info_object.html#ab3b27370e4d7d9f28016fa949d57218f',1,'KoFrMaDaemon.Backup.FileInfoObject.RelativePath()'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_folder_object.html#aecbd0b6f23ebde0637320a270eac2c21',1,'KoFrMaDaemon.Backup.FolderObject.RelativePath()']]],
  ['relativepaths',['RelativePaths',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_object.html#a24a7ae8018d05ab5f4c2f29322b1051b',1,'KoFrMaDaemon::Backup::BackupJournalObject']]],
  ['request',['Request',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_request.html',1,'KoFrMaDaemon::ConnectionToServer']]],
  ['returnhashcodesfiles',['ReturnHashCodesFiles',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_operations.html#a633b155d2745d8efd03a94ac6c16c0d6',1,'KoFrMaDaemon::Backup::BackupJournalOperations']]],
  ['returnhashcodesfolders',['ReturnHashCodesFolders',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_operations.html#a4413740734c338f80929f6b728ebf127',1,'KoFrMaDaemon::Backup::BackupJournalOperations']]],
  ['rsaciphering',['RSACiphering',['../class_ko_fr_ma_daemon_1_1_r_s_a_ciphering.html',1,'KoFrMaDaemon']]]
];
