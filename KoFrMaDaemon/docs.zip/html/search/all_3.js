var searchData=
[
  ['completedtasks',['CompletedTasks',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_request.html#ac80327b7b6c25ba6508f534fdb56a96f',1,'KoFrMaDaemon::ConnectionToServer::Request']]],
  ['compression',['Compression',['../class_ko_fr_ma_daemon_1_1_backup_1_1_compression.html',1,'KoFrMaDaemon::Backup']]],
  ['compressionlevel',['CompressionLevel',['../class_ko_fr_ma_daemon_1_1_backup_1_1_destination7z.html#a9d80365fe5f776e3652e313a714d2e51',1,'KoFrMaDaemon.Backup.Destination7z.CompressionLevel()'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_destination_rar.html#afa467dcac9b59ee51994fec2b87ef28f',1,'KoFrMaDaemon.Backup.DestinationRar.CompressionLevel()'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_destination_zip.html#a411c02ea9cddd52c40ef60223257748e',1,'KoFrMaDaemon.Backup.DestinationZip.CompressionLevel()']]],
  ['compressto7z',['CompressTo7z',['../class_ko_fr_ma_daemon_1_1_backup_1_1_compression.html#aaa60f31ac86c60745b7036727a0f259d',1,'KoFrMaDaemon::Backup::Compression']]],
  ['compresstorar',['CompressToRar',['../class_ko_fr_ma_daemon_1_1_backup_1_1_compression.html#a1cad152d4c8048a424de9851a915d937',1,'KoFrMaDaemon::Backup::Compression']]],
  ['compresstozip',['CompressToZip',['../class_ko_fr_ma_daemon_1_1_backup_1_1_compression.html#adce2b55cc60c0f01afec02f779cc2f89',1,'KoFrMaDaemon::Backup::Compression']]],
  ['connection',['Connection',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_connection.html',1,'KoFrMaDaemon::ConnectionToServer']]],
  ['connectionfailed',['ConnectionFailed',['../class_ko_fr_ma_daemon_1_1_timer_values.html#ad9bdc3c14ecf38d80d3f2597af59ff4d',1,'KoFrMaDaemon::TimerValues']]],
  ['connectionsuccess',['ConnectionSuccess',['../class_ko_fr_ma_daemon_1_1_timer_values.html#afc95af802b92c33c86336ef1576714f0',1,'KoFrMaDaemon::TimerValues']]],
  ['copyerrorobject',['CopyErrorObject',['../class_ko_fr_ma_daemon_1_1_backup_1_1_copy_error_object.html',1,'KoFrMaDaemon::Backup']]],
  ['createbackupjournal',['CreateBackupJournal',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_operations.html#a62d5860990e43eb40c5cfa0efbec35d6',1,'KoFrMaDaemon::Backup::BackupJournalOperations']]],
  ['creationtimeutc',['CreationTimeUtc',['../class_ko_fr_ma_daemon_1_1_backup_1_1_file_info_object.html#ad87bbd12a5296f3f358e829fee0c49a1',1,'KoFrMaDaemon.Backup.FileInfoObject.CreationTimeUtc()'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_folder_object.html#af9adcaddac2a55afcbcbff1cb146d0a4',1,'KoFrMaDaemon.Backup.FolderObject.CreationTimeUtc()']]]
];
