var searchData=
[
  ['backupjournalnew',['BackupJournalNew',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_switch.html#a2f2d46790fa921ab5efc29434e1819bb',1,'KoFrMaDaemon::Backup::BackupSwitch']]]
];
