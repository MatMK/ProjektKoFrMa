var searchData=
[
  ['backup',['Backup',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_switch.html#a4be1bd3b453d9ce7fdb7336d745a681f',1,'KoFrMaDaemon::Backup::BackupSwitch']]],
  ['backupmssql',['BackupMSSQL',['../class_ko_fr_ma_daemon_1_1_backup_1_1_s_q_l_backup.html#aad2652a9c864691e1553310dff20d670',1,'KoFrMaDaemon::Backup::SQLBackup']]],
  ['backupmysql',['BackupMySQL',['../class_ko_fr_ma_daemon_1_1_backup_1_1_s_q_l_backup.html#a7a1a1fd2ceaa0bf76e7562c868446c90',1,'KoFrMaDaemon::Backup::SQLBackup']]]
];
