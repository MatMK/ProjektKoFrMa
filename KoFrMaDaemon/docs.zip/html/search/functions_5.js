var searchData=
[
  ['kofrmadaemon',['KoFrMaDaemon',['../class_ko_fr_ma_daemon_1_1_ko_fr_ma_daemon.html#a0a42bb978862a93c2c55811e13b21c23',1,'KoFrMaDaemon::KoFrMaDaemon']]]
];
