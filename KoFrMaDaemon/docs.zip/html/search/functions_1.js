var searchData=
[
  ['compressto7z',['CompressTo7z',['../class_ko_fr_ma_daemon_1_1_backup_1_1_compression.html#aaa60f31ac86c60745b7036727a0f259d',1,'KoFrMaDaemon::Backup::Compression']]],
  ['compresstorar',['CompressToRar',['../class_ko_fr_ma_daemon_1_1_backup_1_1_compression.html#a1cad152d4c8048a424de9851a915d937',1,'KoFrMaDaemon::Backup::Compression']]],
  ['compresstozip',['CompressToZip',['../class_ko_fr_ma_daemon_1_1_backup_1_1_compression.html#adce2b55cc60c0f01afec02f779cc2f89',1,'KoFrMaDaemon::Backup::Compression']]],
  ['createbackupjournal',['CreateBackupJournal',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_operations.html#a62d5860990e43eb40c5cfa0efbec35d6',1,'KoFrMaDaemon::Backup::BackupJournalOperations']]]
];
