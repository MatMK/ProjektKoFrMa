var searchData=
[
  ['serverip',['ServerIP',['../class_ko_fr_ma_daemon_1_1_settings_load.html#a137534c679a2ab1d2b68aebbc3c3ec91',1,'KoFrMaDaemon::SettingsLoad']]],
  ['sevenzippath',['SevenZipPath',['../class_ko_fr_ma_daemon_1_1_settings_load.html#aec1acc2996cc0caf33ef27a3fa267adc',1,'KoFrMaDaemon::SettingsLoad']]]
];
