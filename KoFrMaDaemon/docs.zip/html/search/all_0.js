var searchData=
[
  ['_5floglevel',['_logLevel',['../class_ko_fr_ma_daemon_1_1_debug_log.html#ad8cd37f346f9e81716306c985109468d',1,'KoFrMaDaemon::DebugLog']]]
];
