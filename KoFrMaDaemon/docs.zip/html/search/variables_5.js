var searchData=
[
  ['taskdebuglog',['taskDebugLog',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_switch.html#a5516e336b8a76981050e2deae6adf794',1,'KoFrMaDaemon::Backup::BackupSwitch']]]
];
