var searchData=
[
  ['debuglog',['DebugLog',['../class_ko_fr_ma_daemon_1_1_debug_log.html#a4dbf72444a28792d98a336777470858d',1,'KoFrMaDaemon::DebugLog']]],
  ['dispose',['Dispose',['../class_ko_fr_ma_daemon_1_1_ko_fr_ma_daemon.html#ac052d31a34b090d46d0005f987a8b6f8',1,'KoFrMaDaemon.KoFrMaDaemon.Dispose()'],['../class_ko_fr_ma_daemon_1_1_project_installer.html#aa2754339e44b6dde5a7d0b08d7433a31',1,'KoFrMaDaemon.ProjectInstaller.Dispose()']]]
];
