var searchData=
[
  ['onstart',['OnStart',['../class_ko_fr_ma_daemon_1_1_timer_values.html#a61adf51ff0fa213ca040cec8ac21ebd7',1,'KoFrMaDaemon::TimerValues']]],
  ['os',['OS',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_daemon_info.html#a80c7b8f229996efbdfba560dd3e8739a',1,'KoFrMaDaemon::ConnectionToServer::DaemonInfo']]]
];
