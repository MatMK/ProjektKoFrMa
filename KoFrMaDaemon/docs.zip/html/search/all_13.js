var searchData=
[
  ['task',['Task',['../class_ko_fr_ma_daemon_1_1_task.html',1,'KoFrMaDaemon']]],
  ['taskcomplete',['TaskComplete',['../class_ko_fr_ma_daemon_1_1_task_complete.html',1,'KoFrMaDaemon']]],
  ['taskdatahash',['TaskDataHash',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_task_version.html#ad13792c6ce099f099378b68d98f8cf95',1,'KoFrMaDaemon::ConnectionToServer::TaskVersion']]],
  ['taskdebuglog',['taskDebugLog',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_switch.html#a5516e336b8a76981050e2deae6adf794',1,'KoFrMaDaemon::Backup::BackupSwitch']]],
  ['taskid',['TaskID',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_task_version.html#ae131b14263c0790a5adf54212d1e967f',1,'KoFrMaDaemon::ConnectionToServer::TaskVersion']]],
  ['tasksversions',['TasksVersions',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_request.html#ad408435fe81493b1f4e143d2ef68cb75',1,'KoFrMaDaemon::ConnectionToServer::Request']]],
  ['taskversion',['TaskVersion',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_task_version.html',1,'KoFrMaDaemon::ConnectionToServer']]],
  ['temporaryfoldermaxbuffer',['TemporaryFolderMaxBuffer',['../class_ko_fr_ma_daemon_1_1_task.html#a2dff62cb46d5b7afbe7407d460a59141',1,'KoFrMaDaemon::Task']]],
  ['timeofcompletition',['TimeOfCompletition',['../class_ko_fr_ma_daemon_1_1_task_complete.html#a4924bf30289b4b76f70a7ec6c767b2f8',1,'KoFrMaDaemon::TaskComplete']]],
  ['timerticks',['TimerTicks',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_timer_ticks.html',1,'KoFrMaDaemon::ConnectionToServer']]],
  ['timervalues',['TimerValues',['../class_ko_fr_ma_daemon_1_1_timer_values.html',1,'KoFrMaDaemon.TimerValues'],['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_daemon_settings.html#a8597c7c09d49d102eeb823778d4523a1',1,'KoFrMaDaemon.ConnectionToServer.DaemonSettings.TimerValues()']]],
  ['timetobackup',['TimeToBackup',['../class_ko_fr_ma_daemon_1_1_task.html#abc96da193c13a4e84ca17baf3ce7a52f',1,'KoFrMaDaemon::Task']]],
  ['token',['Token',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_daemon_info.html#ad63fb0e4c2f238d243bde399941967be',1,'KoFrMaDaemon::ConnectionToServer::DaemonInfo']]]
];
