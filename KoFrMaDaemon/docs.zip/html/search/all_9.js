var searchData=
[
  ['id',['Id',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_daemon_info.html#ae0b63886861d7660091cdcf6ad636058',1,'KoFrMaDaemon::ConnectionToServer::DaemonInfo']]],
  ['idestination',['IDestination',['../interface_ko_fr_ma_daemon_1_1_backup_1_1_i_destination.html',1,'KoFrMaDaemon::Backup']]],
  ['idestinationpath',['IDestinationPath',['../interface_ko_fr_ma_daemon_1_1_backup_1_1_i_destination_path.html',1,'KoFrMaDaemon::Backup']]],
  ['idtask',['IDTask',['../class_ko_fr_ma_daemon_1_1_task.html#a79ac85fc8d83ffebbcaef66ef7a65f7f',1,'KoFrMaDaemon.Task.IDTask()'],['../class_ko_fr_ma_daemon_1_1_task_complete.html#a75559fc06a4db2d57fb5e2061e80b983',1,'KoFrMaDaemon.TaskComplete.IDTask()']]],
  ['inprogress',['InProgress',['../class_ko_fr_ma_daemon_1_1_task.html#a128319e1f45f0730e397bb3c44a6e0ce',1,'KoFrMaDaemon::Task']]],
  ['instance',['Instance',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_daemon_info.html#a80e141c88ac757d1bc4c9f72e5dc26b3',1,'KoFrMaDaemon.ConnectionToServer.DaemonInfo.Instance()'],['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_password.html#a64098dae026b122d4361b49fb9b390ee',1,'KoFrMaDaemon.ConnectionToServer.Password.Instance()']]],
  ['isource',['ISource',['../interface_ko_fr_ma_daemon_1_1_backup_1_1_i_source.html',1,'KoFrMaDaemon::Backup']]],
  ['issuccessfull',['IsSuccessfull',['../class_ko_fr_ma_daemon_1_1_task_complete.html#a96ed167f9aad7b426ce4166582ff48dc',1,'KoFrMaDaemon::TaskComplete']]]
];
