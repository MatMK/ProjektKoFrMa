var searchData=
[
  ['locallogpath',['LocalLogPath',['../class_ko_fr_ma_daemon_1_1_settings_load.html#aa29d8d6f63ced0e143e4085495b338af',1,'KoFrMaDaemon::SettingsLoad']]],
  ['logreport',['logReport',['../class_ko_fr_ma_daemon_1_1_debug_log.html#a11640ee23a7f96645169457e54bb25ef',1,'KoFrMaDaemon::DebugLog']]]
];
