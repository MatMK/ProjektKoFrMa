var searchData=
[
  ['exceptionmessage',['ExceptionMessage',['../class_ko_fr_ma_daemon_1_1_backup_1_1_copy_error_object.html#a6729a13f83fb369d28a1efb14f1923aa',1,'KoFrMaDaemon::Backup::CopyErrorObject']]]
];
