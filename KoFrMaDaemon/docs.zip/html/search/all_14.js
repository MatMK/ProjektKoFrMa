var searchData=
[
  ['uploadtoftp',['UploadToFTP',['../class_ko_fr_ma_daemon_1_1_backup_1_1_f_t_p_connection.html#a353362c5d6d874f6d826f32ca99d5e32',1,'KoFrMaDaemon::Backup::FTPConnection']]],
  ['uploadtossh',['UploadToSSH',['../class_ko_fr_ma_daemon_1_1_backup_1_1_s_s_h_connection.html#a5bffde68d19814d2cfdf09d549f4e804',1,'KoFrMaDaemon::Backup::SSHConnection']]]
];
