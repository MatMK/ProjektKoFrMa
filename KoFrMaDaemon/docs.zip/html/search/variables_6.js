var searchData=
[
  ['windowslog',['WindowsLog',['../class_ko_fr_ma_daemon_1_1_settings_load.html#a4bbb1de3c051709f8dc6db5900ab9418',1,'KoFrMaDaemon::SettingsLoad']]],
  ['winrarpath',['WinRARPath',['../class_ko_fr_ma_daemon_1_1_settings_load.html#aee302b4e3782873a555ac64631bdd273',1,'KoFrMaDaemon::SettingsLoad']]]
];
