var searchData=
[
  ['backupjournalobject',['BackupJournalObject',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_object.html',1,'KoFrMaDaemon::Backup']]],
  ['backupjournaloperations',['BackupJournalOperations',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_operations.html',1,'KoFrMaDaemon::Backup']]],
  ['backupswitch',['BackupSwitch',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_switch.html',1,'KoFrMaDaemon::Backup']]]
];
