var searchData=
[
  ['journalid',['JournalID',['../class_ko_fr_ma_daemon_1_1_backup_1_1_source_journal_load_from_cache.html#a603b4a4b4092053475f7d9955ad53085',1,'KoFrMaDaemon::Backup::SourceJournalLoadFromCache']]]
];
