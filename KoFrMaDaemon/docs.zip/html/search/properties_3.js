var searchData=
[
  ['daemon',['daemon',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_request.html#afe8f70f52b3cbc728e2da2055ebc282b',1,'KoFrMaDaemon::ConnectionToServer::Request']]],
  ['databasename',['DatabaseName',['../class_ko_fr_ma_daemon_1_1_backup_1_1_source_m_s_s_q_l.html#a356941cd4a54d624ddef17ebec52e275',1,'KoFrMaDaemon.Backup.SourceMSSQL.DatabaseName()'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_source_my_s_q_l.html#a1da92b165c7c37d6399c02b68649d94b',1,'KoFrMaDaemon.Backup.SourceMySQL.DatabaseName()']]],
  ['datfile',['DatFile',['../class_ko_fr_ma_daemon_1_1_task_complete.html#aeafc4322b1ce6f3f3b1cb721a7aeb0a2',1,'KoFrMaDaemon::TaskComplete']]],
  ['debuglog',['DebugLog',['../class_ko_fr_ma_daemon_1_1_task_complete.html#aa711ccf9c37767abe1695e45430e86b8',1,'KoFrMaDaemon::TaskComplete']]],
  ['destinationpath',['DestinationPath',['../class_ko_fr_ma_daemon_1_1_backup_1_1_file_copy_info.html#a0b9474b804a505f54ea3a715fd63cf18',1,'KoFrMaDaemon.Backup.FileCopyInfo.DestinationPath()'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_folder_copy_info.html#aad341fc6fc8a4f18e4d95a1f219d3db8',1,'KoFrMaDaemon.Backup.FolderCopyInfo.DestinationPath()']]],
  ['destinations',['Destinations',['../class_ko_fr_ma_daemon_1_1_task.html#ad0f2260f11dc5f07f64cb9d1285a93f6',1,'KoFrMaDaemon::Task']]]
];
