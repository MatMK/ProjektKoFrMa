var searchData=
[
  ['backup',['Backup',['../namespace_ko_fr_ma_daemon_1_1_backup.html',1,'KoFrMaDaemon']]],
  ['connectiontoserver',['ConnectionToServer',['../namespace_ko_fr_ma_daemon_1_1_connection_to_server.html',1,'KoFrMaDaemon']]],
  ['kofrmadaemon',['KoFrMaDaemon',['../namespace_ko_fr_ma_daemon.html',1,'']]],
  ['properties',['Properties',['../namespace_ko_fr_ma_daemon_1_1_properties.html',1,'KoFrMaDaemon']]]
];
