var searchData=
[
  ['attributes',['Attributes',['../class_ko_fr_ma_daemon_1_1_backup_1_1_file_info_object.html#aaf822624e7c4b71ffa286f6f655e59cb',1,'KoFrMaDaemon.Backup.FileInfoObject.Attributes()'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_folder_object.html#a1128bc8a48e1bbf916e0b122a5d1fadd',1,'KoFrMaDaemon.Backup.FolderObject.Attributes()']]]
];
