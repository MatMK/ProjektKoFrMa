var searchData=
[
  ['version',['Version',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_daemon_info.html#ab9181064ae3e528df018fefe12728648',1,'KoFrMaDaemon::ConnectionToServer::DaemonInfo']]]
];
