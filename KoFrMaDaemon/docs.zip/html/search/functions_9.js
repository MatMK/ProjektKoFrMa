var searchData=
[
  ['setpassword',['SetPassword',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_password.html#a3c0c56ea4c0eedb5f656adb787f30359',1,'KoFrMaDaemon::ConnectionToServer::Password']]],
  ['settingsload',['SettingsLoad',['../class_ko_fr_ma_daemon_1_1_settings_load.html#a884673227463038d5993c984fdebeec4',1,'KoFrMaDaemon::SettingsLoad']]],
  ['sshconnection',['SSHConnection',['../class_ko_fr_ma_daemon_1_1_backup_1_1_s_s_h_connection.html#aa14b64483987bebc84dd2e090e0ad181',1,'KoFrMaDaemon.Backup.SSHConnection.SSHConnection(string SSHAddress, string username, string password, DebugLog debugLog)'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_s_s_h_connection.html#a67ec917d0a1be76deb5adb4437fab854',1,'KoFrMaDaemon.Backup.SSHConnection.SSHConnection(string SSHAddress, NetworkCredential networkCredential)'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_s_s_h_connection.html#a6d057c337ffaababb1bc4947236804fc',1,'KoFrMaDaemon.Backup.SSHConnection.SSHConnection(DestinationPathSFTP destinationPathSFTP)']]]
];
