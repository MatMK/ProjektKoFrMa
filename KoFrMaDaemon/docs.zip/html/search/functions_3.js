var searchData=
[
  ['ftpconnection',['FTPConnection',['../class_ko_fr_ma_daemon_1_1_backup_1_1_f_t_p_connection.html#ab9a704e0dc7ce6791170b66d9afde910',1,'KoFrMaDaemon.Backup.FTPConnection.FTPConnection(string FTPAddress, string username, string password)'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_f_t_p_connection.html#abf3c3137bb87785c144096e422e3dfa2',1,'KoFrMaDaemon.Backup.FTPConnection.FTPConnection(string FTPAddress, NetworkCredential networkCredential)'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_f_t_p_connection.html#a1df2060e5bafa606560d5c63075a804f',1,'KoFrMaDaemon.Backup.FTPConnection.FTPConnection(DestinationPathFTP destinationPathFTP)']]]
];
