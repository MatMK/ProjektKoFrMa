var searchData=
[
  ['idestination',['IDestination',['../interface_ko_fr_ma_daemon_1_1_backup_1_1_i_destination.html',1,'KoFrMaDaemon::Backup']]],
  ['idestinationpath',['IDestinationPath',['../interface_ko_fr_ma_daemon_1_1_backup_1_1_i_destination_path.html',1,'KoFrMaDaemon::Backup']]],
  ['isource',['ISource',['../interface_ko_fr_ma_daemon_1_1_backup_1_1_i_source.html',1,'KoFrMaDaemon::Backup']]]
];
