var indexSectionsWithContent =
{
  0: "_abcdefghijklmnoprstuvw",
  1: "bcdfikprst",
  2: "k",
  3: "bcdfgkmprsuw",
  4: "_blpstw",
  5: "abcdefhijlmnoprstv",
  6: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "properties",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Properties",
  6: "Pages"
};

