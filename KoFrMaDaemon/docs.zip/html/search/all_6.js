var searchData=
[
  ['filecopyinfo',['FileCopyInfo',['../class_ko_fr_ma_daemon_1_1_backup_1_1_file_copy_info.html',1,'KoFrMaDaemon::Backup']]],
  ['fileinfoobject',['FileInfoObject',['../class_ko_fr_ma_daemon_1_1_backup_1_1_file_info_object.html',1,'KoFrMaDaemon::Backup']]],
  ['foldercopyinfo',['FolderCopyInfo',['../class_ko_fr_ma_daemon_1_1_backup_1_1_folder_copy_info.html',1,'KoFrMaDaemon::Backup']]],
  ['folderobject',['FolderObject',['../class_ko_fr_ma_daemon_1_1_backup_1_1_folder_object.html',1,'KoFrMaDaemon::Backup']]],
  ['ftpconnection',['FTPConnection',['../class_ko_fr_ma_daemon_1_1_backup_1_1_f_t_p_connection.html',1,'KoFrMaDaemon.Backup.FTPConnection'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_f_t_p_connection.html#ab9a704e0dc7ce6791170b66d9afde910',1,'KoFrMaDaemon.Backup.FTPConnection.FTPConnection(string FTPAddress, string username, string password)'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_f_t_p_connection.html#abf3c3137bb87785c144096e422e3dfa2',1,'KoFrMaDaemon.Backup.FTPConnection.FTPConnection(string FTPAddress, NetworkCredential networkCredential)'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_f_t_p_connection.html#a1df2060e5bafa606560d5c63075a804f',1,'KoFrMaDaemon.Backup.FTPConnection.FTPConnection(DestinationPathFTP destinationPathFTP)']]],
  ['fullpath',['FullPath',['../class_ko_fr_ma_daemon_1_1_backup_1_1_copy_error_object.html#a214aa05baebfc76a02193f15dc4096fa',1,'KoFrMaDaemon.Backup.CopyErrorObject.FullPath()'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_file_info_object.html#aebe9a4aa59e05d65cc1ffbeaad751b55',1,'KoFrMaDaemon.Backup.FileInfoObject.FullPath()'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_folder_object.html#a1c39957382ccdb0ad47c264cbf65d8a0',1,'KoFrMaDaemon.Backup.FolderObject.FullPath()']]]
];
