var searchData=
[
  ['completedtasks',['CompletedTasks',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_request.html#ac80327b7b6c25ba6508f534fdb56a96f',1,'KoFrMaDaemon::ConnectionToServer::Request']]],
  ['compressionlevel',['CompressionLevel',['../class_ko_fr_ma_daemon_1_1_backup_1_1_destination7z.html#a9d80365fe5f776e3652e313a714d2e51',1,'KoFrMaDaemon.Backup.Destination7z.CompressionLevel()'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_destination_rar.html#afa467dcac9b59ee51994fec2b87ef28f',1,'KoFrMaDaemon.Backup.DestinationRar.CompressionLevel()'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_destination_zip.html#a411c02ea9cddd52c40ef60223257748e',1,'KoFrMaDaemon.Backup.DestinationZip.CompressionLevel()']]],
  ['connectionfailed',['ConnectionFailed',['../class_ko_fr_ma_daemon_1_1_timer_values.html#ad9bdc3c14ecf38d80d3f2597af59ff4d',1,'KoFrMaDaemon::TimerValues']]],
  ['connectionsuccess',['ConnectionSuccess',['../class_ko_fr_ma_daemon_1_1_timer_values.html#afc95af802b92c33c86336ef1576714f0',1,'KoFrMaDaemon::TimerValues']]],
  ['creationtimeutc',['CreationTimeUtc',['../class_ko_fr_ma_daemon_1_1_backup_1_1_file_info_object.html#ad87bbd12a5296f3f358e829fee0c49a1',1,'KoFrMaDaemon.Backup.FileInfoObject.CreationTimeUtc()'],['../class_ko_fr_ma_daemon_1_1_backup_1_1_folder_object.html#af9adcaddac2a55afcbcbff1cb146d0a4',1,'KoFrMaDaemon.Backup.FolderObject.CreationTimeUtc()']]]
];
