var searchData=
[
  ['lastwritetimeutc',['LastWriteTimeUtc',['../class_ko_fr_ma_daemon_1_1_backup_1_1_file_info_object.html#a9c101f4fb53e47eed0d125b74f8c78f6',1,'KoFrMaDaemon::Backup::FileInfoObject']]],
  ['length',['Length',['../class_ko_fr_ma_daemon_1_1_backup_1_1_file_info_object.html#a059ab8bc4efc7532d830282bbf21c532',1,'KoFrMaDaemon::Backup::FileInfoObject']]],
  ['loglevel',['LogLevel',['../class_ko_fr_ma_daemon_1_1_task.html#ab1226af9eb0301d4e349798ceebe18cc',1,'KoFrMaDaemon::Task']]]
];
