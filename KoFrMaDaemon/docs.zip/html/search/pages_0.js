var searchData=
[
  ['license',['LICENSE',['../md__e_1__users__matej__source__repos__projekt_ko_fr_ma__ko_fr_ma_daemon_packages__newtonsoft_8_json_811_80_81__l_i_c_e_n_s_e.html',1,'']]],
  ['license',['LICENSE',['../md__e_1__users__matej__source__repos__projekt_ko_fr_ma__ko_fr_ma_daemon_packages__newtonsoft_8_json_811_80_82__l_i_c_e_n_s_e.html',1,'']]]
];
