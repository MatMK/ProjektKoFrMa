var searchData=
[
  ['backup',['Backup',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_switch.html#a4be1bd3b453d9ce7fdb7336d745a681f',1,'KoFrMaDaemon::Backup::BackupSwitch']]],
  ['backupjournalfiles',['BackupJournalFiles',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_object.html#addfc0d21ea4ff75f3ad0c89b195ef41e',1,'KoFrMaDaemon::Backup::BackupJournalObject']]],
  ['backupjournalfilesdelete',['BackupJournalFilesDelete',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_object.html#a4048e78c9ab49a50304aab71d38ef65f',1,'KoFrMaDaemon::Backup::BackupJournalObject']]],
  ['backupjournalfolders',['BackupJournalFolders',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_object.html#a16061e72e1e832de40ec54d86b77fd26',1,'KoFrMaDaemon::Backup::BackupJournalObject']]],
  ['backupjournalfoldersdelete',['BackupJournalFoldersDelete',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_object.html#ae24981c1cf33a7766bb4c498eb931638',1,'KoFrMaDaemon::Backup::BackupJournalObject']]],
  ['backupjournalnew',['BackupJournalNew',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_switch.html#a2f2d46790fa921ab5efc29434e1819bb',1,'KoFrMaDaemon::Backup::BackupSwitch']]],
  ['backupjournalnotneeded',['BackupJournalNotNeeded',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_request.html#adad7964e9c90ddaaa677a2905d0cb4ff',1,'KoFrMaDaemon::ConnectionToServer::Request']]],
  ['backupjournalobject',['BackupJournalObject',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_object.html',1,'KoFrMaDaemon::Backup']]],
  ['backupjournaloperations',['BackupJournalOperations',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_operations.html',1,'KoFrMaDaemon::Backup']]],
  ['backupmssql',['BackupMSSQL',['../class_ko_fr_ma_daemon_1_1_backup_1_1_s_q_l_backup.html#aad2652a9c864691e1553310dff20d670',1,'KoFrMaDaemon::Backup::SQLBackup']]],
  ['backupmysql',['BackupMySQL',['../class_ko_fr_ma_daemon_1_1_backup_1_1_s_q_l_backup.html#a7a1a1fd2ceaa0bf76e7562c868446c90',1,'KoFrMaDaemon::Backup::SQLBackup']]],
  ['backupswitch',['BackupSwitch',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_switch.html',1,'KoFrMaDaemon::Backup']]]
];
