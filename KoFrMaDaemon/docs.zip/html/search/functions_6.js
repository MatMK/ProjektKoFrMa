var searchData=
[
  ['mergejournalobjects',['MergeJournalObjects',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_operations.html#ab759a6dfb4345cc746950a63cdc1957f',1,'KoFrMaDaemon::Backup::BackupJournalOperations']]]
];
