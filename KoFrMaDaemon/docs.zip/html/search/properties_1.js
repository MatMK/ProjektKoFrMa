var searchData=
[
  ['backupjournalfiles',['BackupJournalFiles',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_object.html#addfc0d21ea4ff75f3ad0c89b195ef41e',1,'KoFrMaDaemon::Backup::BackupJournalObject']]],
  ['backupjournalfilesdelete',['BackupJournalFilesDelete',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_object.html#a4048e78c9ab49a50304aab71d38ef65f',1,'KoFrMaDaemon::Backup::BackupJournalObject']]],
  ['backupjournalfolders',['BackupJournalFolders',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_object.html#a16061e72e1e832de40ec54d86b77fd26',1,'KoFrMaDaemon::Backup::BackupJournalObject']]],
  ['backupjournalfoldersdelete',['BackupJournalFoldersDelete',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_object.html#ae24981c1cf33a7766bb4c498eb931638',1,'KoFrMaDaemon::Backup::BackupJournalObject']]],
  ['backupjournalnotneeded',['BackupJournalNotNeeded',['../class_ko_fr_ma_daemon_1_1_connection_to_server_1_1_request.html#adad7964e9c90ddaaa677a2905d0cb4ff',1,'KoFrMaDaemon::ConnectionToServer::Request']]]
];
