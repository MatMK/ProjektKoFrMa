var searchData=
[
  ['returnhashcodesfiles',['ReturnHashCodesFiles',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_operations.html#a633b155d2745d8efd03a94ac6c16c0d6',1,'KoFrMaDaemon::Backup::BackupJournalOperations']]],
  ['returnhashcodesfolders',['ReturnHashCodesFolders',['../class_ko_fr_ma_daemon_1_1_backup_1_1_backup_journal_operations.html#a4413740734c338f80929f6b728ebf127',1,'KoFrMaDaemon::Backup::BackupJournalOperations']]]
];
