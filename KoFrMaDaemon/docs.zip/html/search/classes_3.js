var searchData=
[
  ['filecopyinfo',['FileCopyInfo',['../class_ko_fr_ma_daemon_1_1_backup_1_1_file_copy_info.html',1,'KoFrMaDaemon::Backup']]],
  ['fileinfoobject',['FileInfoObject',['../class_ko_fr_ma_daemon_1_1_backup_1_1_file_info_object.html',1,'KoFrMaDaemon::Backup']]],
  ['foldercopyinfo',['FolderCopyInfo',['../class_ko_fr_ma_daemon_1_1_backup_1_1_folder_copy_info.html',1,'KoFrMaDaemon::Backup']]],
  ['folderobject',['FolderObject',['../class_ko_fr_ma_daemon_1_1_backup_1_1_folder_object.html',1,'KoFrMaDaemon::Backup']]],
  ['ftpconnection',['FTPConnection',['../class_ko_fr_ma_daemon_1_1_backup_1_1_f_t_p_connection.html',1,'KoFrMaDaemon::Backup']]]
];
